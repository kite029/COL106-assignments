#include<iostream>
#include<vector>
using namespace std;
int binarysearchh(vector<int>v,int num){

    int s=0;
    int e=v.size()-1;
    int mid=s+(e-s)/2;
    while(s<=e){
        if(v[mid]==num){
            return mid;
        }
        if(v[mid]>num){
            e=mid-1;
        }
        else{
            s=mid+1;
        }
        mid=s+(e-s)/2;
        
    }
    return -1;
}
class SET{
    public:
    vector<int> vec;
    int size(){
        return vec.size();
    }
    int binarysearch(int num){

    int s=0;
    int e=vec.size()-1;
    int mid=s+(e-s)/2;
    while(s<=e){
        if(vec[mid]==num){
            return mid;
        }
        if(vec[mid]>num){
            e=mid-1;
        }
        else{
            s=mid+1;
        }
        mid=s+(e-s)/2;
        
    }
    return -1;
    }
    void Insert(int data){
        vec.push_back(data);
        //return vec.size();
        //sorrt here
    }
    int Delete(int data){
        vec.erase(vec.begin()+data);   
    }
    int Union(vector<int>vec2){
        int i=0;
        int j=0;
        while(i<vec.size() and j<vec2.size()){
            if(vec[i]==vec2[j]){
                i++;
                j++;
            }
            else{
                if(vec[i]<vec2[j]){
                    i++;
                }
                else{
                    vec.push_back(vec2[j]);
                    j++;
                }
            } 
        } 
        while(j<vec2.size()){
            vec.push_back(vec2[j]);
            j++;
        }
    return vec.size();
        //sort vec here

    }   
    int Intersection(vector<int>vec2){
        int i=0;
        int j=0;
        while(i<vec.size() and j<vec2.size()){
            if(vec[i]==vec2[j]){
                i++;
                j++;
            }
            else{
                if(vec[i]<vec2[j]){
                    vec.erase(vec.begin()+i); 
                }
                else{
                    j++;
                }
            } 
        }
        while(i<vec.size()){
            vec.erase(vec.begin()+i);
        }
    return vec.size();
        //no need of sortt i think.
    }
    int Difference(vector<int>vec2){
        int i=0;
        int j=0;
        while(i<vec.size() and j<vec2.size()){
            if(vec[i]==vec2[j]){
                vec.erase(vec.begin()+i);    
            }
            else{
                if(vec[i]<vec2[j]){
                    i++;
                }
                else{
                    j++;
                }
            } 
        }
    //no need to sort
    return vec.size();

    }
    int SymmetricDifference(vector<int>vec2){
        int i=0;
        int j=0;
        while(i<vec.size() and j<vec2.size()){
            if(vec[i]==vec2[j]){
                vec.erase(vec.begin()+i);  
                j++;
                
            }
            else{
                if(vec[i]<vec2[j]){
                    i++;
                }
                else{
                    vec.push_back(vec2[j]);
                    j++;
                }
            } 
        }
        while(j<vec2.size()){
            vec.push_back(vec2[j]);
            j++;
        }
        //no sort needed check

        return vec.size();
    }
    void print(){
        if(vec.size()>0){
            for( int i=0; i<vec.size()-1; i++){
                cout<<vec[i]<<",";
            }
            cout<<vec[vec.size()-1];
        }
        cout<<endl;
    }
    vector<int> converttovector(){
        vector<int> z;
        for(int i=0; i<vec.size(); i++){
            z.push_back(vec[i]);
        }
        return z;
    }
    void sortt() {
        for(int i=0;i<vec.size();i++){
            int temp=vec[i];
            int j=i-1;
            while(j>=0 and temp<vec[j]){
                vec[j+1]=vec[j];
                j=j-1;
            }
            vec[j+1]=temp;
        }
 
    }
};
int main(){
    SET sets[100005];
    vector<int> setnum;
    int x,y,z;
    while(true){
            cin>>x;
            if(!cin){
            break;
        }
            if(x==1){
                cin>>y>>z;
                if(sets[y].binarysearch(z)==-1){//check whether binary search working for 0 size.
                    sets[y].Insert(z);
                    sets[y].sortt();
                    cout<<sets[y].size()<<endl;
                }
                if (binarysearchh(setnum,y)==-1){
                    setnum.push_back(y);
                } 
            }
            else if(x==2){
                cin>>y>>z;
                if(binarysearchh(setnum,y)==-1){
                        cout<<"-1"<<endl;
                    }
                else
                {
                    if (sets[y].binarysearch(z)==-1){
                        cout<<sets[y].size()<<endl;
                    }
                    else{
                        sets[y].Delete(sets[y].binarysearch(z));
                    }
                }
            }
            else if(x==3){
                cin>>y>>z;
                if(binarysearchh(setnum,y)==-1){
                    cout<<"-1"<<endl;
                }
                else{
                    if (sets[y].binarysearch(z)==-1){
                        cout<<"0"<<endl;
                    }
                    else{
                        cout<<"1"<<endl;
                    }
                }      
            }
            else if(x==4){
                cin>>y>>z;
                cout<<sets[y].Union(sets[z].converttovector())<<endl;
                sets[y].sortt();   
            }
            else if(x==5){
                cin>>y>>z;
                cout<<sets[y].Intersection(sets[z].converttovector())<<endl; 
                sets[y].sortt();   
            }
            else if(x==6){
                cin>>y;
                if(binarysearchh(setnum,y)==-1){
                    setnum.push_back(y);
                    cout<<"0"<<endl;
                }
                else{
                cout<<sets[y].size()<<endl;
                }   
            }       
            else if(x==7){
                cin>>y>>z;
                cout<<sets[y].Difference(sets[z].converttovector())<<endl;
                sets[y].sortt();
            }      
            else if(x==8){
                cin>>y>>z;
                cout<<sets[y].SymmetricDifference(sets[z].converttovector())<<endl;
                sets[y].sortt();   
            }       
            else if(x==9){   
                cin>>y;  
                sets[y].print();  
            }
        }       
    }





    





   

